
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Restrict listing on public bucket: drop broad SELECT, replace with restricted policy
DROP POLICY IF EXISTS "portfolio_public_read" ON storage.objects;
-- Only allow public read via specific object paths (no listing). Authenticated admins can list.
CREATE POLICY "portfolio_admin_list" ON storage.objects FOR SELECT TO authenticated USING (bucket_id='portfolio' AND public.has_role(auth.uid(),'admin'));
