CREATE TABLE public.video_quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  whatsapp text NOT NULL,
  brand_name text NOT NULL,
  content_type text NOT NULL,
  requirements text,
  service_type text NOT NULL,
  videos_per_day integer NOT NULL DEFAULT 1,
  duration_days integer NOT NULL DEFAULT 1,
  estimated_price integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT INSERT ON public.video_quote_requests TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON public.video_quote_requests TO authenticated;
GRANT ALL ON public.video_quote_requests TO service_role;

ALTER TABLE public.video_quote_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "quote_public_insert" ON public.video_quote_requests
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "quote_admin_select" ON public.video_quote_requests
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "quote_admin_update" ON public.video_quote_requests
  FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "quote_admin_delete" ON public.video_quote_requests
  FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));