DROP POLICY IF EXISTS "quote_public_insert" ON public.video_quote_requests;
REVOKE INSERT ON public.video_quote_requests FROM anon, authenticated;