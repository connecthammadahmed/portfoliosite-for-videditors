import { Globe, ShoppingBag, Layout, Film, Megaphone, MessageCircle } from "lucide-react";

const services = [
  { icon: Globe, title: "Website Development", desc: "Custom-coded sites built for speed, SEO, and conversion." },
  { icon: ShoppingBag, title: "Shopify Development", desc: "Premium storefronts that turn browsers into buyers." },
  { icon: Layout, title: "Wix Studio Development", desc: "Designer-grade sites without compromising flexibility." },
  { icon: Film, title: "Video Editing", desc: "Cinematic edits, reels, and brand films with story-first pacing." },
  { icon: Megaphone, title: "Digital Marketing", desc: "Paid + organic strategies focused on measurable ROI." },
  { icon: MessageCircle, title: "WhatsApp Automation", desc: "Automated funnels and CRM flows that scale conversations." },
];

export function ServicesSection() {
  return (
    <section id="services" className="relative px-5 py-24 sm:px-6 md:px-12 md:py-32">
      <div className="mx-auto max-w-6xl">
        <span className="reveal mb-6 inline-block text-xs uppercase tracking-[0.32em] text-primary/80">
          Services
        </span>
        <h2 className="reveal reveal-delay-1 font-display max-w-3xl text-3xl leading-tight tracking-tight text-foreground sm:text-4xl md:text-6xl">
          A complete <em className="italic text-primary">digital</em> ecosystem.
        </h2>
        <p className="reveal reveal-delay-2 mt-6 max-w-2xl text-sm text-muted-foreground sm:text-base">
          Six disciplines, one creator. Pick a service or combine them into a full
          launch — every project is delivered with the same cinematic standard.
        </p>

        <div className="mt-12 grid gap-5 sm:mt-16 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className={`reveal reveal-delay-${Math.min((i % 4) + 1, 4)} group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.05] to-white/[0.01] p-6 backdrop-blur-xl transition-all duration-500 hover:-translate-y-2 hover:scale-[1.015] hover:border-primary/50 hover:shadow-[0_30px_80px_-20px_rgba(255,140,60,0.35)] sm:p-7`}
            >
              <div className="absolute -right-12 -top-12 h-32 w-32 rounded-full bg-primary/20 opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100" />
              <div className="relative">
                <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10 text-primary transition-all duration-500 group-hover:scale-110 group-hover:rotate-6 group-hover:bg-primary/20">
                  <Icon size={22} />
                </div>
                <h3 className="font-display text-xl tracking-tight text-foreground sm:text-2xl">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
