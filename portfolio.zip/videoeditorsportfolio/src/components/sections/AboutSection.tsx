import { Code2, Film, TrendingUp, Bot } from "lucide-react";

const skills = [
  { icon: Code2, title: "Website Development", desc: "Modern, fast, conversion-focused builds." },
  { icon: Film, title: "Video Editing", desc: "Cinematic storytelling and motion design." },
  { icon: TrendingUp, title: "Digital Marketing", desc: "Growth campaigns that compound." },
  { icon: Bot, title: "Automation Solutions", desc: "WhatsApp & workflow automation." },
];

export function AboutSection() {
  return (
    <section id="about" className="relative px-5 py-24 sm:px-6 md:px-12 md:py-32">
      <div className="mx-auto max-w-6xl">
        <span className="reveal mb-6 inline-block text-xs uppercase tracking-[0.32em] text-primary/80">
          About
        </span>
        <h2 className="reveal reveal-delay-1 font-display max-w-3xl text-3xl leading-tight tracking-tight text-foreground sm:text-4xl md:text-6xl">
          About <em className="italic text-primary">Deepak</em>
        </h2>
        <div className="reveal reveal-delay-2 mt-8 grid max-w-3xl gap-6 text-sm leading-relaxed text-muted-foreground sm:text-base md:text-lg">
          <p>
            I help businesses build powerful digital identities through modern websites,
            cinematic content creation, and performance-driven marketing strategies.
          </p>
          <p>
            From Shopify stores and business websites to social media campaigns and
            professional video editing, I create complete digital ecosystems that drive
            measurable growth.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:mt-16 sm:grid-cols-2 lg:grid-cols-4">
          {skills.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className={`reveal reveal-delay-${Math.min(i + 1, 4)} hover-lift group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-md hover:border-primary/50 hover:bg-white/[0.07] hover:shadow-[0_20px_60px_-20px_rgba(255,140,60,0.35)]`}
            >
              <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/0 via-primary/0 to-primary/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3">
                <Icon size={20} />
              </div>
              <h3 className="text-sm font-semibold tracking-wide text-foreground">{title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
