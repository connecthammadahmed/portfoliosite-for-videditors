import { Mail, MessageCircle, Instagram, ArrowUpRight } from "lucide-react";

const channels = [
  { icon: Mail, label: "Email", value: "cinespry@gmail.com", href: "mailto:cinespry@gmail.com" },
  { icon: MessageCircle, label: "WhatsApp", value: "+91 8072036018", href: "https://wa.me/918072036018?text=" },
  { icon: Instagram, label: "Instagram", value: "@by_deepakkk", href: "https://www.instagram.com/by_deepakkk/" },
];

export function ContactSection() {
  return (
    <section id="contact" className="relative px-5 py-24 sm:px-6 md:px-12 md:py-32">
      <div className="mx-auto max-w-5xl text-center">
        <span className="reveal mb-6 inline-block text-xs uppercase tracking-[0.32em] text-primary/80">
          Contact
        </span>
        <h2 className="reveal reveal-delay-1 font-display mx-auto max-w-4xl text-4xl leading-[0.95] tracking-tight text-foreground sm:text-5xl md:text-7xl">
          Let's build something{" "}
          <em className="italic bg-gradient-to-r from-primary to-orange-300 bg-clip-text text-transparent">
            exceptional.
          </em>
        </h2>
        <p className="reveal reveal-delay-2 mx-auto mt-6 max-w-xl text-sm text-muted-foreground sm:mt-8 sm:text-base">
          Have a project, a vision, or a brand that deserves a cinematic upgrade?
          Reach out — I reply within 24 hours.
        </p>

        <div className="mt-12 flex flex-wrap justify-center gap-4 sm:mt-14">
          {channels.map(({ icon: Icon, label, value, href }, i) => (
            <a
              key={label}
              href={href}
              target={href.startsWith("http") ? "_blank" : undefined}
              rel="noopener noreferrer"
              className={`reveal reveal-delay-${Math.min(i + 1, 4)} group flex w-full max-w-xs flex-col items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-left backdrop-blur-md transition-all duration-500 hover:-translate-y-2 hover:scale-[1.02] hover:border-primary/50 hover:bg-white/[0.07] hover:shadow-[0_20px_60px_-20px_rgba(255,140,60,0.35)] sm:w-72`}
            >
              <div className="flex w-full items-center justify-between">
                <Icon size={18} className="text-primary transition-transform duration-500 group-hover:scale-110" />
                <ArrowUpRight size={16} className="text-muted-foreground transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
              </div>
              <div>
                <div className="text-[0.65rem] uppercase tracking-[0.24em] text-muted-foreground">{label}</div>
                <div className="mt-1 text-sm text-foreground">{value}</div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
