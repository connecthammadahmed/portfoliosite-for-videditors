import { useEffect, useState } from "react";

export function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const DURATION = 1800;

    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / DURATION);
      // ease-out
      const eased = 1 - Math.pow(1 - t, 3);
      setProgress(Math.round(eased * 100));
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        setTimeout(() => setHidden(true), 350);
      }
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div
      aria-hidden={hidden}
      className={`fixed inset-0 z-[100] grid place-items-center bg-background transition-opacity duration-500 ${
        hidden ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
      style={{ backgroundImage: "var(--gradient-cinematic)" }}
    >
      <div className="flex w-[min(420px,82vw)] flex-col items-center text-center">
        <p className="mb-3 text-[10px] uppercase tracking-[0.42em] text-primary">
          Portfolio · 2026
        </p>
        <h1 className="font-display text-5xl leading-none tracking-tight sm:text-6xl">
          By <span className="italic text-primary">Deepak</span>
        </h1>

        <div className="mt-10 h-[2px] w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full bg-gradient-to-r from-primary/70 via-primary to-primary/70 transition-[width] duration-100 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="mt-3 flex w-full items-center justify-between text-[10px] uppercase tracking-[0.32em] text-muted-foreground">
          <span>Loading</span>
          <span className="tabular-nums text-foreground/80">{progress}%</span>
        </div>
      </div>
    </div>
  );
}
