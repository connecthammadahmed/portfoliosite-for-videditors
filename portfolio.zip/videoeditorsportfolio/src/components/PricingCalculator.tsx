import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { X, Loader2, Film, Mic, Check, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { submitQuoteRequest } from "@/lib/quotes.functions";

type ServiceKey = "reel" | "podcast";

const LENGTHS = [30, 90, 120] as const;
type LengthKey = (typeof LENGTHS)[number];

const SERVICES: Record<
  ServiceKey,
  {
    label: string;
    icon: typeof Film;
    desc: string;
    pricing: Record<LengthKey, number>;
  }
> = {
  reel: {
    label: "Reel Editing",
    icon: Film,
    desc: "Short-form reels, Instagram content, promotional videos.",
    pricing: { 30: 499, 90: 699, 120: 799 },
  },
  podcast: {
    label: "Podcast / B-Roll Editing",
    icon: Mic,
    desc: "Multi-camera podcasts, cinematic b-roll, YouTube content.",
    pricing: { 30: 799, 90: 999, 120: 1199 },
  },
};

const CONTENT_TYPES = [
  "Real Estate",
  "Clothing Brand",
  "Podcast",
  "Personal Brand",
  "Restaurant",
  "Education",
  "Startup",
  "Other",
];

function useAnimatedNumber(target: number, duration = 500) {
  const [val, setVal] = useState(target);
  const prev = useRef(target);
  useEffect(() => {
    const from = prev.current;
    const start = performance.now();
    let raf: number;
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(Math.round(from + (target - from) * eased));
      if (t < 1) raf = requestAnimationFrame(step);
      else prev.current = target;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}

export function PricingCalculator({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const submit = useServerFn(submitQuoteRequest);
  const [service, setService] = useState<ServiceKey>("reel");
  const [videos, setVideos] = useState(1);
  const [length, setLength] = useState<LengthKey>(30);
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [brand, setBrand] = useState("");
  const [contentType, setContentType] = useState(CONTENT_TYPES[0]);
  const [requirements, setRequirements] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const perVideo = SERVICES[service].pricing[length];
  const total = useMemo(() => perVideo * videos, [perVideo, videos]);
  const animatedTotal = useAnimatedNumber(total);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  const reset = () => {
    setService("reel");
    setVideos(1);
    setLength(30);
    setName("");
    setWhatsapp("");
    setBrand("");
    setContentType(CONTENT_TYPES[0]);
    setRequirements("");
    setSuccess(false);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !whatsapp.trim() || !brand.trim()) {
      toast.error("Please fill in name, WhatsApp and brand name.");
      return;
    }
    setLoading(true);
    try {
      await submit({
        data: {
          name: name.trim(),
          whatsapp: whatsapp.trim(),
          brand_name: brand.trim(),
          content_type: contentType,
          requirements: requirements.trim() || null,
          service_type: service,
          videos_per_day: videos,
          duration_days: length,
          estimated_price: total,
        },
      });

      const msg = encodeURIComponent(
        `Hi, I'd like a detailed quote.\n\nName: ${name}\nBrand: ${brand}\nWhatsApp: ${whatsapp}\nService: ${SERVICES[service].label}\nVideos: ${videos}\nVideo Length: ${length} seconds\nEstimated Price: ${formatINR(total)}\n\nRequirements:\n${requirements || "-"}`,
      );
      window.open(`https://wa.me/918072036018?text=${msg}`, "_blank", "noopener,noreferrer");
      setSuccess(true);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Submission failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6"
      onClick={handleClose}
    >
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
        aria-hidden
      />
      <div
        className="relative z-10 max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-3xl border border-white/10 bg-gradient-to-b from-[oklch(0.16_0.015_40)] to-[oklch(0.1_0.012_40)] shadow-[0_30px_120px_-20px_rgba(255,122,0,0.35)] animate-in fade-in zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          aria-label="Close"
          className="absolute right-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full border border-white/15 bg-black/40 text-white/80 backdrop-blur transition hover:scale-110 hover:border-primary hover:text-primary"
        >
          <X size={16} />
        </button>

        {success ? (
          <SuccessView onClose={handleClose} />
        ) : (
          <div className="p-6 sm:p-10">
            <header className="mb-8">
              <p className="mb-2 text-[10px] uppercase tracking-[0.4em] text-primary">
                — Instant Estimate
              </p>
              <h2 className="font-display text-3xl leading-tight sm:text-5xl">
                Calculate Your <span className="italic text-primary">Project Cost</span>
              </h2>
              <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
                Get an instant estimate for your content requirements. Final pricing may vary
                depending on complexity.
              </p>
            </header>

            {/* Services */}
            <div className="mb-8 grid gap-3 sm:grid-cols-2">
              {(Object.keys(SERVICES) as ServiceKey[]).map((k) => {
                const s = SERVICES[k];
                const Icon = s.icon;
                const selected = service === k;
                return (
                  <button
                    key={k}
                    onClick={() => setService(k)}
                    className={`group relative overflow-hidden rounded-2xl border p-5 text-left transition-all duration-300 ${
                      selected
                        ? "border-primary bg-primary/10 shadow-[0_0_40px_-10px_oklch(0.72_0.18_50/0.6)]"
                        : "border-white/10 bg-white/[0.02] hover:border-white/30"
                    }`}
                  >
                    <div className="mb-3 flex items-center justify-between">
                      <div
                        className={`grid h-11 w-11 place-items-center rounded-xl border ${
                          selected
                            ? "border-primary/60 bg-primary/20 text-primary"
                            : "border-white/15 bg-white/5 text-white/70"
                        }`}
                      >
                        <Icon size={20} />
                      </div>
                      {selected && (
                        <span className="grid h-6 w-6 place-items-center rounded-full bg-primary text-primary-foreground">
                          <Check size={14} />
                        </span>
                      )}
                    </div>
                    <h3 className="font-display text-2xl">{s.label}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{s.desc}</p>
                    <p className="mt-3 text-sm">
                      <span className="text-muted-foreground">Starting </span>
                      <span className="font-semibold text-primary">{formatINR(s.pricing[30])}</span>
                      <span className="text-muted-foreground"> / 30s video</span>
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Sliders */}
            <div className="mb-8 grid gap-5 sm:grid-cols-2">
              <SliderCard
                label="Number of Videos"
                value={videos}
                min={1}
                max={30}
                onChange={setVideos}
                suffix={videos === 1 ? "video" : "videos"}
              />
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                <div className="mb-3 flex items-baseline justify-between">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    Video Length
                  </p>
                  <p className="font-display text-2xl tabular-nums">
                    {length}
                    <span className="ml-1 text-sm text-muted-foreground">seconds</span>
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {LENGTHS.map((l) => {
                    const active = length === l;
                    return (
                      <button
                        key={l}
                        type="button"
                        onClick={() => setLength(l)}
                        className={`rounded-xl border px-3 py-3 text-sm font-medium transition ${
                          active
                            ? "border-primary bg-primary/15 text-primary"
                            : "border-white/10 bg-black/20 text-white/70 hover:border-white/30"
                        }`}
                      >
                        <div className="font-display text-lg leading-none">{l}s</div>
                        <div className="mt-1 text-[10px] uppercase tracking-wider opacity-80">
                          {formatINR(SERVICES[service].pricing[l])}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Pricing */}
            <div className="mb-10 overflow-hidden rounded-2xl border border-primary/40 bg-gradient-to-br from-primary/20 via-primary/5 to-transparent p-6">
              <p className="text-[10px] uppercase tracking-[0.3em] text-primary">
                Estimated Cost
              </p>
              <p className="mt-2 font-display text-5xl tabular-nums sm:text-6xl">
                {formatINR(animatedTotal)}
              </p>
              <div className="mt-4 grid gap-2 text-xs text-white/70 sm:grid-cols-3">
                <span className="flex items-center gap-1.5">
                  <Check size={12} className="text-primary" /> Based on current selection
                </span>
                <span className="flex items-center gap-1.5">
                  <Check size={12} className="text-primary" /> Final quote depends on footage
                </span>
                <span className="flex items-center gap-1.5">
                  <Check size={12} className="text-primary" /> Bulk discounts available
                </span>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="font-display text-2xl">Your Details</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field
                  label="Full Name"
                  value={name}
                  onChange={setName}
                  placeholder="Deepak Sharma"
                  required
                />
                <Field
                  label="WhatsApp Number"
                  value={whatsapp}
                  onChange={setWhatsapp}
                  placeholder="+91 98765 43210"
                  type="tel"
                  required
                />
                <Field
                  label="Brand Name"
                  value={brand}
                  onChange={setBrand}
                  placeholder="Your brand or company"
                  required
                />
                <div>
                  <label className="mb-1.5 block text-xs uppercase tracking-wider text-muted-foreground">
                    Content Type
                  </label>
                  <select
                    value={contentType}
                    onChange={(e) => setContentType(e.target.value)}
                    className="h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-sm outline-none transition focus:border-primary"
                  >
                    {CONTENT_TYPES.map((c) => (
                      <option key={c} value={c} className="bg-background">
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs uppercase tracking-wider text-muted-foreground">
                  Project Requirements
                </label>
                <textarea
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  placeholder="Tell us about your editing requirements..."
                  rows={4}
                  maxLength={4000}
                  className="w-full resize-none rounded-xl border border-white/10 bg-black/30 p-3 text-sm outline-none transition focus:border-primary"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-primary py-4 font-medium text-primary-foreground transition hover:scale-[1.01] disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" /> Sending…
                  </>
                ) : (
                  <>
                    <MessageCircle size={16} /> Request Detailed Quote
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

function SliderCard({
  label,
  value,
  min,
  max,
  onChange,
  suffix,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
  suffix: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
      <div className="mb-3 flex items-baseline justify-between">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="font-display text-2xl tabular-nums">
          {value} <span className="text-sm text-muted-foreground">{suffix}</span>
        </p>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-primary"
      />
      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required,
}: {
  label: string;
  value: string;
  onChange: (s: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs uppercase tracking-wider text-muted-foreground">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        maxLength={200}
        className="h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-sm outline-none transition focus:border-primary"
      />
    </div>
  );
}

function SuccessView({ onClose }: { onClose: () => void }) {
  return (
    <div className="p-10 text-center sm:p-16">
      <div className="mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full border border-primary/40 bg-primary/15 text-4xl">
        🎉
      </div>
      <h2 className="font-display text-4xl">Quote Request Submitted</h2>
      <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
        We&apos;ll review your requirements and contact you on WhatsApp within 24 hours.
      </p>
      <button
        onClick={onClose}
        className="mt-8 rounded-xl border border-primary/40 bg-primary/10 px-6 py-3 text-sm font-medium text-primary transition hover:bg-primary hover:text-primary-foreground"
      >
        Back to Portfolio
      </button>
    </div>
  );
}
