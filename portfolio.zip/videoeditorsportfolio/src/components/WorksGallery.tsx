import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { Volume2, VolumeX, Play, Calculator } from "lucide-react";
import { getPublicWorks } from "@/lib/admin.functions";
import { PricingCalculator } from "@/components/PricingCalculator";

interface Work {
  id: string;
  title: string;
  description: string | null;
  category: "web" | "video" | "marketing";
  media_url: string;
  media_type: "image" | "video";
  thumbnail_url: string | null;
  external_url: string | null;
  featured: boolean;
  views: number;
}

function formatViews(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(n % 1_000 === 0 ? 0 : 1) + "K";
  return n.toString();
}

function useCountUp(target: number, run: boolean, duration = 1800) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!run) return;
    if (target <= 0) {
      setVal(0);
      return;
    }
    let raf: number;
    const start = performance.now();
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(Math.floor(eased * target));
      if (t < 1) raf = requestAnimationFrame(step);
      else setVal(target);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, run, duration]);
  return val;
}

export function WorksGallery() {
  const loadWorks = useServerFn(getPublicWorks);
  const [pricingOpen, setPricingOpen] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["works-public"],
    queryFn: async (): Promise<Work[]> => (await loadWorks()) as Work[],
  });

  const reels = (data ?? []).map((w) => ({
    ...w,
    views: Number(w.views ?? 0),
  }));

  return (
    <section
      id="works"
      className="relative min-h-screen px-5 py-20 sm:px-6 sm:py-24 md:px-12 lg:px-20"
      style={{ backgroundImage: "var(--gradient-cinematic)" }}
    >
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-xs uppercase tracking-[0.32em] text-primary">— Selected Reels</p>
            <h2 className="font-display text-4xl leading-[0.95] tracking-tight sm:text-5xl md:text-7xl">
              Stories, sites
              <br />
              <span className="italic text-muted-foreground">& systems.</span>
            </h2>
          </div>
          <button
            onClick={() => setPricingOpen(true)}
            className="group inline-flex items-center justify-center gap-2 self-start rounded-full border border-primary/40 bg-primary/10 px-6 py-3 text-sm font-medium text-primary backdrop-blur transition hover:scale-105 hover:bg-primary hover:text-primary-foreground hover:shadow-[0_0_40px_-5px_oklch(0.72_0.18_50/0.7)] sm:self-end"
          >
            <Calculator size={16} className="transition-transform group-hover:rotate-6" />
            Get Pricing
          </button>
        </div>
        <PricingCalculator open={pricingOpen} onClose={() => setPricingOpen(false)} />

        {isLoading ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="aspect-[9/16] animate-pulse rounded-2xl bg-card/60" />
            ))}
          </div>
        ) : reels.length === 0 ? (
          <div className="glass mx-auto max-w-2xl rounded-3xl p-12 text-center">
            <p className="font-display text-3xl">No reels uploaded yet.</p>
            <p className="mt-3 text-sm text-muted-foreground">
              New reels will appear here soon.
            </p>
          </div>
        ) : (
          <ReelsCarousel reels={reels} />
        )}
      </div>
    </section>
  );
}

function ReelsCarousel({ reels }: { reels: Work[] }) {
  const autoplay = useRef(
    Autoplay({ delay: 3500, stopOnInteraction: false, stopOnMouseEnter: false }),
  );
  const [emblaRef] = useEmblaCarousel(
    { loop: true, align: "start", containScroll: "trimSnaps" },
    [autoplay.current],
  );
  const [activeId, setActiveId] = useState<string | null>(null);

  const handleMuteChange = (id: string, muted: boolean) => {
    const ap = autoplay.current;
    if (muted) {
      setActiveId((curr) => (curr === id ? null : curr));
      ap?.play?.();
    } else {
      setActiveId(id);
      ap?.stop?.();
    }
  };

  return (
    <div className="relative">
      <div ref={emblaRef} className="overflow-hidden">
        <div className="flex -ml-3 sm:-ml-4">
          {reels.map((w, i) => (
            <div
              key={w.id}
              className="min-w-0 shrink-0 grow-0 basis-[78%] pl-3 sm:basis-[45%] sm:pl-4 md:basis-[32%] lg:basis-[24%]"
            >
              <ReelCard
                reel={w}
                index={i}
                forceMute={activeId !== null && activeId !== w.id}
                onMuteChange={(m) => handleMuteChange(w.id, m)}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ReelCard({
  reel,
  index,
  forceMute,
  onMuteChange,
}: {
  reel: Work;
  index: number;
  forceMute?: boolean;
  onMuteChange?: (muted: boolean) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [inView, setInView] = useState(false);
  const [muted, setMuted] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const count = useCountUp(reel.views, inView);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
        const v = videoRef.current;
        if (!v) return;
        if (entry.isIntersecting) v.play().catch(() => {});
        else {
          v.pause();
          v.muted = true;
          if (!muted) {
            setMuted(true);
            onMuteChange?.(true);
          }
        }
      },
      { threshold: 0.4 },
    );
    obs.observe(node);
    return () => obs.disconnect();
  }, [muted, onMuteChange]);

  useEffect(() => {
    if (forceMute && !muted) {
      setMuted(true);
    }
  }, [forceMute, muted]);

  useEffect(() => {
    const v = videoRef.current;
    if (v) v.muted = muted;
  }, [muted]);

  const toggleMute = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setMuted((m) => {
      const next = !m;
      onMuteChange?.(next);
      return next;
    });
  };


  const Card = (
    <article
      ref={ref}
      className="group relative overflow-hidden rounded-2xl border border-border bg-black transition-all duration-500 hover:border-primary/40"
      style={{
        animation: `float-up 0.8s cubic-bezier(0.22,0.61,0.36,1) ${index * 0.06}s both`,
      }}
    >
      <div className="relative aspect-[9/16] overflow-hidden bg-black">
        {reel.media_type === "video" ? (
          <>
            {!loaded && (
              <div className="absolute inset-0 z-10 grid place-items-center bg-black">
                {reel.thumbnail_url ? (
                  <img
                    src={reel.thumbnail_url}
                    alt={reel.title}
                    className="absolute inset-0 h-full w-full object-cover opacity-80"
                  />
                ) : null}
                <div className="relative h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-primary" />
              </div>
            )}
            <video
              ref={videoRef}
              src={`${reel.media_url}#t=0.1`}
              poster={reel.thumbnail_url ?? undefined}
              muted={muted}
              loop
              playsInline
              autoPlay
              preload="auto"
              onLoadedData={() => setLoaded(true)}
              onCanPlay={() => setLoaded(true)}
              className="h-full w-full object-cover"
            />
          </>
        ) : (
          <img
            src={reel.media_url}
            alt={reel.title}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />

        {reel.featured && (
          <span className="absolute left-3 top-3 rounded-full border border-primary/50 bg-primary/15 px-2.5 py-1 text-[9px] uppercase tracking-widest text-primary backdrop-blur">
            Featured
          </span>
        )}

        {reel.media_type === "video" && (
          <button
            onClick={toggleMute}
            aria-label={muted ? "Unmute" : "Mute"}
            className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full border border-white/30 bg-black/60 text-white shadow-lg backdrop-blur transition hover:scale-110 hover:bg-primary hover:text-primary-foreground"
          >
            {muted ? <VolumeX size={15} /> : <Volume2 size={15} />}
          </button>
        )}

        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="font-display text-lg leading-tight text-white">{reel.title}</h3>
          {reel.description && (
            <p className="mt-1 line-clamp-2 text-xs text-white/70">{reel.description}</p>
          )}
          <div className="mt-2 flex items-center gap-1.5 text-xs text-white/90">
            <Play size={11} className="fill-white text-white" />
            <span className="font-medium tabular-nums">{formatViews(count)}</span>
            <span className="text-white/60">views</span>
          </div>
        </div>
      </div>
    </article>
  );

  return reel.external_url ? (
    <a href={reel.external_url} target="_blank" rel="noopener noreferrer" className="block">
      {Card}
    </a>
  ) : (
    Card
  );
}
