import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { Pause, Play, Volume2, VolumeX, ArrowRight } from "lucide-react";
import heroAsset from "@/assets/hero-frame.mp4.asset.json";
import heroOverlayAsset from "@/assets/hero-overlay.mp4.asset.json";
import { CinematicLayer } from "./CinematicLayer";
import styles from "./VideoIntro.module.css";

interface VideoIntroProps {
  firstName?: string;
  lastName?: string;
  tagline?: string;
  subtitle?: React.ReactNode;
  onScrollNext?: () => void;
}

export function VideoIntro({
  firstName = "Ananya",
  lastName = "Verma",
  tagline = "Creative Technologist · Portfolio 2026",
  subtitle = (
    <>
      I craft <span className={styles.subtitleAccent}>cinematic web experiences</span>,
      direct video stories, and architect digital marketing systems
      for brands that refuse to feel ordinary.
    </>
  ),
  onScrollNext,
}: VideoIntroProps) {
  const fgRef = useRef<HTMLVideoElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [hintVisible, setHintVisible] = useState(true);

  useEffect(() => {
    if (!contentRef.current) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "expo.out" } });
      tl.to(`.${styles.tagline}`, { opacity: 1, y: 0, duration: 1.1, delay: 0.3 })
        .to(`.${styles.nameLine}`, { opacity: 1, y: 0, duration: 1.4, stagger: 0.12 }, "-=0.7")
        .to(`.${styles.subtitle}`, { opacity: 1, duration: 1.2 }, "-=0.8")
        .to(`.${styles.ctaRow}`, { opacity: 1, y: 0, duration: 0.9 }, "-=0.7")
        .to(`.${styles.videoFrame}`, { opacity: 1, y: 0, duration: 1.4 }, "-=1.4")
        .to(`.${styles.controls}`, { opacity: 1, duration: 0.8 }, "-=0.5")
        .to(`.${styles.scrollIndicator}`, { opacity: 1, duration: 0.8 }, "-=0.4");
    }, contentRef);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setHintVisible(false), 5500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const fg = fgRef.current;
    if (!fg) return;
    if (fg.readyState >= 2) setLoaded(true);
    const onReady = () => setLoaded(true);
    fg.addEventListener("loadeddata", onReady);
    fg.addEventListener("canplay", onReady);
    const tryPlay = () => fg.play().catch(() => {});
    tryPlay();
    return () => {
      fg.removeEventListener("loadeddata", onReady);
      fg.removeEventListener("canplay", onReady);
    };
  }, []);

  const togglePlay = () => {
    const fg = fgRef.current;
    if (!fg) return;
    if (fg.paused) { fg.play(); setPlaying(true); }
    else { fg.pause(); setPlaying(false); }
  };

  const toggleMute = () => {
    const fg = fgRef.current;
    if (!fg) return;
    const next = !muted;
    fg.muted = next;
    setMuted(next);
    setHintVisible(false);
  };

  const handleScrollNext = () => {
    if (onScrollNext) return onScrollNext();
    document.getElementById("works")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section className={styles.hero} ref={contentRef}>
      <video
        className={styles.bgOverlayVideo}
        src={heroOverlayAsset.url}
        autoPlay
        loop
        muted
        playsInline
        aria-hidden
      />
      <div className={styles.bgOverlayTint} aria-hidden />
      <div className={styles.stars} aria-hidden />
      <div className={styles.aurora} aria-hidden />
      <div className={styles.aurora2} aria-hidden />
      <CinematicLayer />

      <div className={styles.grid}>
        <div className={styles.left}>
          <span className={styles.tagline}>{tagline}</span>
          <h1 className={`${styles.name} font-display`}>
            <span className={styles.nameLine}>{firstName}</span>
            <span className={`${styles.nameLine} ${styles.nameLast}`}>{lastName}</span>
          </h1>
          <p className={styles.subtitle}>{subtitle}</p>
          <div className={styles.ctaRow}>
            <button type="button" onClick={handleScrollNext} className={styles.ctaPrimary}>
              View Work <ArrowRight size={14} />
            </button>
            <a href="#contact" className={styles.ctaGhost}>Get in touch</a>
          </div>
        </div>

        <div className={styles.right}>
          <div className={styles.videoFrame}>
            <div className={styles.glow} aria-hidden />
            <video
              ref={fgRef}
              className={`${styles.fgVideo} ${loaded ? styles.fgVideoLoaded : ""}`}
              src={heroAsset.url}
              autoPlay
              loop
              muted
              playsInline
              onLoadedData={() => setLoaded(true)}
              aria-label="Portfolio intro video"
            />
            <button
              type="button"
              onClick={toggleMute}
              className={`${styles.soundBadge} ${!hintVisible ? styles.soundBadgeHidden : ""}`}
              aria-label="Enable sound"
            >
              Tap for sound
            </button>
            <div className={styles.controls}>
              <button type="button" onClick={togglePlay} className={styles.ctrlBtn} aria-label={playing ? "Pause" : "Play"}>
                {playing ? <Pause size={16} /> : <Play size={16} />}
              </button>
              <button type="button" onClick={toggleMute} className={styles.ctrlBtn} aria-label={muted ? "Unmute" : "Mute"}>
                {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      <button type="button" onClick={handleScrollNext} className={styles.scrollIndicator} aria-label="Scroll to next section">
        <span>Scroll</span>
        <span className={styles.scrollLine} />
      </button>
    </section>
  );
}
