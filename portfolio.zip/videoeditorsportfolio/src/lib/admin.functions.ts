import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const publicWorkSelect =
  "id,title,description,category,media_url,media_type,thumbnail_url,external_url,featured,views,sort_order,created_at";




export const checkIsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("user_roles")
      .select("id")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    return { isAdmin: !!data };
  });

const workInputSchema = z.object({
  title: z.string().max(200).optional().nullable().transform((v) => (v && v.trim() ? v : "Untitled")),
  description: z.string().max(2000).optional().nullable(),
  category: z.enum(["web", "video", "marketing"]),
  media_url: z.string().url(),
  media_type: z.enum(["image", "video"]),
  thumbnail_url: z.string().url().optional().nullable(),
  external_url: z.string().url().optional().nullable(),
  featured: z.boolean().optional().default(false),
  views: z.number().int().min(0).optional().default(0),
});

async function requireAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data) throw new Error("Admin access required");
}

export const createWork = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => workInputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    await requireAdmin(userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("works")
      .insert({ ...data, created_by: userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const getPublicWorks = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("works")
    .select(publicWorkSelect)
    .order("featured", { ascending: false })
    .order("sort_order", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) throw new Error(error.message);
  return data ?? [];
});

export const deleteWork = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    await requireAdmin(userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("works").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const updateWorkSchema = z.object({
  id: z.string().uuid(),
  title: z.string().max(200).optional(),
  description: z.string().max(2000).nullable().optional(),
  category: z.enum(["web", "video", "marketing"]).optional(),
  external_url: z.string().url().nullable().optional().or(z.literal("")),
  thumbnail_url: z.string().url().nullable().optional().or(z.literal("")),
  featured: z.boolean().optional(),
  sort_order: z.number().int().optional(),
  views: z.number().int().min(0).optional(),
});


export const updateWork = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => updateWorkSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    await requireAdmin(userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, ...patch } = data;
    if (patch.external_url === "") patch.external_url = null;
    if (patch.thumbnail_url === "") patch.thumbnail_url = null;

    const { data: row, error } = await supabaseAdmin
      .from("works")
      .update(patch)
      .eq("id", id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const reorderWorks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        items: z.array(z.object({ id: z.string().uuid(), sort_order: z.number().int() })).max(500),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    await requireAdmin(userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (const it of data.items) {
      const { error } = await supabaseAdmin
        .from("works")
        .update({ sort_order: it.sort_order })
        .eq("id", it.id);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

const instagramImportSchema = z.object({
  url: z
    .string()
    .url()
    .refine(
      (u) => /(^|\.)instagram\.com\/(reel|reels|p|tv)\//i.test(u),
      "Must be an Instagram reel, post or video URL",
    ),
});

const decodeJson = (s: string) =>
  s
    .replace(/\\u0026/g, "&")
    .replace(/\\u002F/gi, "/")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&");

export const importInstagramReel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => instagramImportSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    await requireAdmin(userId);

    const UA =
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36";

    const shortcodeMatch = data.url.match(
      /instagram\.com\/(?:reel|reels|p|tv)\/([A-Za-z0-9_-]+)/i,
    );
    const shortcode = shortcodeMatch?.[1];
    if (!shortcode) throw new Error("Could not parse Instagram shortcode from URL.");

    const fetchText = async (u: string, extraHeaders: Record<string, string> = {}) => {
      try {
        const r = await fetch(u, {
          headers: {
            "User-Agent": UA,
            "Accept-Language": "en-US,en;q=0.9",
            Accept:
              "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            ...extraHeaders,
          },
          redirect: "follow",
        });
        return { ok: r.ok, text: r.ok ? await r.text() : "" };
      } catch {
        return { ok: false, text: "" };
      }
    };

    const extractFrom = (html: string) => {
      const pick = (re: RegExp) => {
        const m = html.match(re);
        return m ? decodeJson(m[1]) : null;
      };
      return {
        v:
          pick(/<meta[^>]+property=["']og:video:secure_url["'][^>]+content=["']([^"']+)["']/i) ||
          pick(/<meta[^>]+property=["']og:video["'][^>]+content=["']([^"']+)["']/i) ||
          pick(/"video_url":"([^"]+)"/) ||
          pick(/"contentUrl":"([^"]+\.mp4[^"]*)"/) ||
          pick(/"playable_url_quality_hd":"([^"]+)"/) ||
          pick(/"playable_url":"([^"]+)"/),
        t:
          pick(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
          pick(/"display_url":"([^"]+)"/) ||
          pick(/"thumbnail_src":"([^"]+)"/),
        d: pick(
          /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i,
        ),
      };
    };

    let videoUrl: string | null = null;
    let thumbUrl: string | null = null;
    let description: string | null = null;

    const sources = [
      data.url,
      `https://www.instagram.com/reel/${shortcode}/embed/captioned/`,
      `https://www.instagram.com/p/${shortcode}/embed/captioned/`,
      `https://www.instagram.com/p/${shortcode}/embed/`,
    ];
    for (const src of sources) {
      const r = await fetchText(src);
      if (!r.ok) continue;
      const x = extractFrom(r.text);
      videoUrl ||= x.v;
      thumbUrl ||= x.t;
      description ||= x.d;
      if (videoUrl) break;
    }

    // Final fallback: ddinstagram direct mp4 proxy (no key required)
    if (!videoUrl) {
      try {
        const r3 = await fetch(`https://ddinstagram.com/videos/${shortcode}/1`, {
          headers: { "User-Agent": UA },
          redirect: "follow",
        });
        if (r3.ok && (r3.headers.get("content-type") || "").includes("video")) {
          videoUrl = r3.url;
        }
      } catch {}
    }

    if (!videoUrl) {
      throw new Error(
        "Instagram is blocking automated download for this reel. Please upload the video file manually.",
      );
    }

    const vidRes = await fetch(videoUrl, {
      headers: { "User-Agent": UA, Referer: "https://www.instagram.com/" },
    });
    if (!vidRes.ok) throw new Error(`Failed to download video (HTTP ${vidRes.status})`);
    const vidBuf = new Uint8Array(await vidRes.arrayBuffer());
    if (vidBuf.byteLength < 1024) throw new Error("Downloaded video is empty or invalid.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const stamp = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const videoPath = `video/instagram/${stamp}.mp4`;
    const { error: upErr } = await supabaseAdmin.storage
      .from("portfolio")
      .upload(videoPath, vidBuf, { contentType: "video/mp4", upsert: false });
    if (upErr) throw new Error(`Storage upload failed: ${upErr.message}`);
    const media_url = supabaseAdmin.storage.from("portfolio").getPublicUrl(videoPath).data
      .publicUrl;

    let thumbnail_url: string | null = null;
    if (thumbUrl) {
      try {
        const tRes = await fetch(thumbUrl, {
          headers: { "User-Agent": UA, Referer: "https://www.instagram.com/" },
        });
        if (tRes.ok) {
          const tBuf = new Uint8Array(await tRes.arrayBuffer());
          const tPath = `video/instagram/covers/${stamp}.jpg`;
          const { error: tErr } = await supabaseAdmin.storage
            .from("portfolio")
            .upload(tPath, tBuf, { contentType: "image/jpeg", upsert: false });
          if (!tErr) {
            thumbnail_url = supabaseAdmin.storage.from("portfolio").getPublicUrl(tPath).data
              .publicUrl;
          }
        }
      } catch {
        // Thumbnail is best-effort
      }
    }

    return {
      media_url,
      thumbnail_url,
      description: description ? description.slice(0, 500) : null,
      size_mb: Math.round((vidBuf.byteLength / 1024 / 1024) * 10) / 10,
    };
  });
