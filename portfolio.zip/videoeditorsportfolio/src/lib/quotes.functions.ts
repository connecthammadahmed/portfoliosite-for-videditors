import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const submitSchema = z.object({
  name: z.string().trim().min(1).max(120),
  whatsapp: z.string().trim().min(6).max(40),
  brand_name: z.string().trim().min(1).max(160),
  content_type: z.string().trim().min(1).max(80),
  requirements: z.string().trim().max(4000).optional().nullable(),
  service_type: z.enum(["reel", "podcast"]),
  videos_per_day: z.number().int().min(1).max(30),
  duration_days: z.number().int().min(1).max(600),
  estimated_price: z.number().int().min(0).max(10_000_000),
});

async function requireAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Admin access required");
}

export const submitQuoteRequest = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => submitSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("video_quote_requests")
      .insert(data)
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const webhook = process.env.DISCORD_WEBHOOK_URL;
    if (webhook) {
      const serviceLabel =
        data.service_type === "reel" ? "Reel Editing" : "Podcast / B-Roll Editing";
      const priceINR = "₹" + data.estimated_price.toLocaleString("en-IN");
      try {
        await fetch(webhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: "Quote Bot",
            embeds: [
              {
                title: "🎬 New Quote Request",
                color: 0xff7a00,
                fields: [
                  { name: "Name", value: data.name, inline: true },
                  { name: "Brand", value: data.brand_name, inline: true },
                  { name: "WhatsApp", value: data.whatsapp, inline: true },
                  { name: "Service", value: serviceLabel, inline: true },
                  { name: "Content Type", value: data.content_type, inline: true },
                  { name: "Videos", value: String(data.videos_per_day), inline: true },
                  { name: "Length", value: `${data.duration_days}s`, inline: true },
                  { name: "Estimated Price", value: priceINR, inline: true },
                  { name: "Requirements", value: data.requirements?.trim() || "—" },
                ],
                timestamp: new Date().toISOString(),
              },
            ],
          }),
        });
      } catch (e) {
        console.error("Discord webhook failed:", e);
      }
    }

    return { id: row.id };
  });

export const listQuoteRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("video_quote_requests")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const updateQuoteStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["pending", "contacted", "closed"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await requireAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("video_quote_requests")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteQuoteRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await requireAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("video_quote_requests")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
