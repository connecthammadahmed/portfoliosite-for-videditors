import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import {
  checkIsAdmin,
  createWork,
  deleteWork,
  updateWork,
  reorderWorks,
  importInstagramReel,
} from "@/lib/admin.functions";
import { toast } from "sonner";
import {
  LogOut,
  Trash2,
  Upload,
  ShieldCheck,
  Pencil,
  Star,
  StarOff,
  ArrowUp,
  ArrowDown,
  X,
  Search,
  ExternalLink,
  Instagram,
  Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [{ title: "Admin Dashboard" }, { name: "robots", content: "noindex,nofollow" }],
  }),
  component: AdminPage,
});

type Category = "web" | "video";
type MediaType = "image" | "video";

interface Work {
  id: string;
  title: string;
  description: string | null;
  category: Category;
  media_url: string;
  media_type: MediaType;
  thumbnail_url: string | null;
  external_url: string | null;
  featured: boolean;
  views: number;
  sort_order: number;
  created_at: string;
}

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [authReady, setAuthReady] = useState(false);

  
  const checkFn = useServerFn(checkIsAdmin);
  const createFn = useServerFn(createWork);
  const deleteFn = useServerFn(deleteWork);
  const updateFn = useServerFn(updateWork);
  const reorderFn = useServerFn(reorderWorks);

  const [filter, setFilter] = useState<"all" | Category>("all");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Work | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      if (!data.user) {
        navigate({ to: "/auth", replace: true });
      } else {
        setUserEmail(data.user.email ?? null);
        setAuthReady(true);
      }
    });
    return () => {
      mounted = false;
    };
  }, [navigate]);

  const adminQuery = useQuery({
    queryKey: ["is-admin"],
    queryFn: () => checkFn(),
    enabled: authReady,
  });

  const worksQuery = useQuery({
    queryKey: ["works-admin"],
    queryFn: async (): Promise<Work[]> => {
      const { data, error } = await supabase
        .from("works")
        .select("*")
        .order("sort_order", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Work[];
    },
    enabled: authReady,
  });

  const filtered = useMemo(() => {
    const list = worksQuery.data ?? [];
    return list
      .filter((w) => (filter === "all" ? true : w.category === filter))
      .filter((w) =>
        search.trim() === ""
          ? true
          : w.title.toLowerCase().includes(search.toLowerCase()) ||
            (w.description ?? "").toLowerCase().includes(search.toLowerCase()),
      );
  }, [worksQuery.data, filter, search]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["works-admin"] });
    qc.invalidateQueries({ queryKey: ["works-public"] });
  };


  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const toggleFeatured = async (w: Work) => {
    try {
      await updateFn({ data: { id: w.id, featured: !w.featured } });
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  };

  const move = async (w: Work, dir: "up" | "down") => {
    const list = worksQuery.data ?? [];
    const idx = list.findIndex((x) => x.id === w.id);
    const swapIdx = dir === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= list.length) return;
    const a = list[idx];
    const b = list[swapIdx];
    try {
      await reorderFn({
        data: {
          items: [
            { id: a.id, sort_order: b.sort_order },
            { id: b.id, sort_order: a.sort_order },
          ],
        },
      });
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  };

  const persistOrder = async (ordered: Work[]) => {
    const n = ordered.length;
    const items = ordered.map((w, i) => ({ id: w.id, sort_order: n - i }));
    // Optimistic update
    qc.setQueryData(["works-admin"], ordered.map((w, i) => ({ ...w, sort_order: n - i })));
    try {
      await reorderFn({ data: { items } });
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to reorder");
      invalidate();
    }
  };

  const moveToTop = async (w: Work) => {
    const list = worksQuery.data ?? [];
    const next = [w, ...list.filter((x) => x.id !== w.id)];
    await persistOrder(next);
  };

  const handleDrop = async (targetId: string) => {
    const srcId = dragId;
    setDragId(null);
    setOverId(null);
    if (!srcId || srcId === targetId) return;
    const list = worksQuery.data ?? [];
    const src = list.find((x) => x.id === srcId);
    if (!src) return;
    const without = list.filter((x) => x.id !== srcId);
    const targetIdx = without.findIndex((x) => x.id === targetId);
    if (targetIdx < 0) return;
    const next = [...without.slice(0, targetIdx), src, ...without.slice(targetIdx)];
    await persistOrder(next);
  };

  if (!authReady) {
    return (
      <div className="flex min-h-screen items-center justify-center text-muted-foreground">
        Loading…
      </div>
    );
  }

  const isAdmin = adminQuery.data?.isAdmin;
  const list = worksQuery.data ?? [];
  const stats = {
    total: list.length,
    featured: list.filter((w) => w.featured).length,
    web: list.filter((w) => w.category === "web").length,
    video: list.filter((w) => w.category === "video").length,
    totalViews: list.reduce((s, w) => s + Number(w.views ?? 0), 0),
  };

  return (
    <main className="min-h-screen px-6 py-12 md:px-12">
      <div className="mx-auto max-w-7xl">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-6">
          <div>
            <Link
              to="/"
              className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground hover:text-primary"
            >
              ← View site
            </Link>
            <h1 className="font-display mt-2 text-4xl">Admin Dashboard</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Signed in as <span className="text-foreground">{userEmail}</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/admin/video-leads"
              className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-2 text-xs uppercase tracking-widest text-primary hover:bg-primary hover:text-primary-foreground"
            >
              Video Leads
            </Link>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs uppercase tracking-widest hover:border-primary hover:text-primary"
            >
              <LogOut size={14} /> Logout
            </button>
          </div>
        </header>

        {!isAdmin ? (
          <section className="glass mt-10 rounded-2xl p-8 text-center">
            <ShieldCheck className="mx-auto text-primary" size={32} />
            <h2 className="font-display mt-4 text-3xl">Admin access required</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
              Your account does not have admin privileges. Contact the site owner to be granted access.
            </p>
          </section>
        ) : (
          <>
            {/* Stats */}
            <section className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-5">
              <StatCard label="Total" value={stats.total} />
              <StatCard label="Featured" value={stats.featured} />
              <StatCard label="Web" value={stats.web} />
              <StatCard label="Reels" value={stats.video} />
              <StatCard label="Total Views" value={stats.totalViews} />
            </section>

            <UploadForm
              onUploaded={async (input) => {
                await createFn({ data: input });
                invalidate();
                toast.success("Work added.");
              }}
            />

            <BulkUploadForm
              onUploaded={async (input) => {
                await createFn({ data: input });
              }}
              onDone={invalidate}
            />

            {/* Manage */}
            <section className="mt-12">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <h2 className="font-display text-2xl">Manage Works</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {filtered.length} of {list.length} shown
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search
                      size={14}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                    />
                    <input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search…"
                      className="rounded-full border border-border bg-card/40 py-2 pl-9 pr-4 text-xs outline-none focus:border-primary"
                    />
                  </div>
                  {(["all", "web", "video"] as const).map((c) => (
                    <button
                      key={c}
                      onClick={() => setFilter(c)}
                      className={`rounded-full border px-3 py-1.5 text-[11px] uppercase tracking-widest transition ${
                        filter === c
                          ? "border-primary bg-primary/15 text-primary"
                          : "border-border text-muted-foreground hover:border-primary/40"
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {filtered.length === 0 ? (
                <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
                  No works yet. Upload your first one above.
                </div>
              ) : (
                <div>
                  <p className="mt-4 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                    Tip: drag any card to reorder. Order auto-aligns and saves.
                  </p>
                <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {filtered.map((w) => {
                    const idx = list.findIndex((x) => x.id === w.id);
                    const isDragging = dragId === w.id;
                    const isOver = overId === w.id && dragId && dragId !== w.id;
                    return (
                      <article
                        key={w.id}
                        draggable
                        onDragStart={(e) => {
                          setDragId(w.id);
                          e.dataTransfer.effectAllowed = "move";
                        }}
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.dataTransfer.dropEffect = "move";
                          if (overId !== w.id) setOverId(w.id);
                        }}
                        onDragLeave={() => {
                          if (overId === w.id) setOverId(null);
                        }}
                        onDrop={(e) => {
                          e.preventDefault();
                          handleDrop(w.id);
                        }}
                        onDragEnd={() => {
                          setDragId(null);
                          setOverId(null);
                        }}
                        className={`group cursor-grab overflow-hidden rounded-xl border bg-card transition active:cursor-grabbing hover:border-primary/40 ${
                          isDragging
                            ? "opacity-40 border-primary"
                            : isOver
                              ? "border-primary ring-2 ring-primary/40"
                              : "border-border"
                        }`}
                      >
                        <div className="relative aspect-video overflow-hidden bg-black">
                          {w.media_type === "video" ? (
                            <video
                              src={w.media_url}
                              muted
                              loop
                              playsInline
                              onMouseEnter={(e) => e.currentTarget.play().catch(() => {})}
                              onMouseLeave={(e) => e.currentTarget.pause()}
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <img
                              src={w.media_url}
                              alt={w.title}
                              className="h-full w-full object-cover"
                            />
                          )}
                          {w.featured && (
                            <span className="absolute left-3 top-3 rounded-full border border-primary/50 bg-primary/15 px-2 py-0.5 text-[9px] uppercase tracking-widest text-primary backdrop-blur">
                              Featured
                            </span>
                          )}
                          <span className="absolute bottom-3 left-3 rounded-full bg-black/70 px-2 py-0.5 text-[10px] font-medium text-white backdrop-blur">
                            #{idx + 1}
                          </span>
                          <div className="absolute right-3 top-3 flex flex-col gap-1">
                            <button
                              onClick={() => moveToTop(w)}
                              disabled={idx === 0}
                              className="rounded-full bg-primary/90 px-2 py-1 text-[9px] font-semibold uppercase tracking-widest text-primary-foreground hover:bg-primary disabled:opacity-30"
                              aria-label="Move to top"
                              title="Move to top"
                            >
                              Top
                            </button>
                            <button
                              onClick={() => move(w, "up")}
                              disabled={idx === 0}
                              className="rounded-full bg-black/60 p-1.5 text-white hover:bg-primary disabled:opacity-30"
                              aria-label="Move up"
                            >
                              <ArrowUp size={12} />
                            </button>
                            <button
                              onClick={() => move(w, "down")}
                              disabled={idx === list.length - 1}
                              className="rounded-full bg-black/60 p-1.5 text-white hover:bg-primary disabled:opacity-30"
                              aria-label="Move down"
                            >
                              <ArrowDown size={12} />
                            </button>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-[10px] uppercase tracking-widest text-primary">
                                {w.category}
                              </p>
                              <h3 className="font-display truncate text-lg">{w.title}</h3>
                              {w.description && (
                                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                                  {w.description}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="mt-4 flex items-center gap-1">
                            <IconBtn
                              onClick={() => toggleFeatured(w)}
                              label={w.featured ? "Unfeature" : "Feature"}
                            >
                              {w.featured ? <StarOff size={14} /> : <Star size={14} />}
                            </IconBtn>
                            <IconBtn onClick={() => setEditing(w)} label="Edit">
                              <Pencil size={14} />
                            </IconBtn>
                            {w.external_url && (
                              <a
                                href={w.external_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="rounded-full p-2 text-muted-foreground hover:bg-primary/10 hover:text-primary"
                                aria-label="Open external link"
                              >
                                <ExternalLink size={14} />
                              </a>
                            )}
                            <div className="flex-1" />
                            <IconBtn
                              onClick={async () => {
                                if (!confirm(`Delete "${w.title}"?`)) return;
                                await deleteFn({ data: { id: w.id } });
                                invalidate();
                                toast.success("Deleted.");
                              }}
                              label="Delete"
                              danger
                            >
                              <Trash2 size={14} />
                            </IconBtn>
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
                </div>
              )}
            </section>
          </>
        )}
      </div>

      {editing && (
        <EditModal
          work={editing}
          onClose={() => setEditing(null)}
          onSave={async (patch) => {
            await updateFn({ data: { id: editing.id, ...patch } });
            invalidate();
            toast.success("Updated.");
            setEditing(null);
          }}
        />
      )}

      <style>{`
        .input {
          width: 100%;
          padding: 0.75rem 1rem;
          background: oklch(0.18 0.015 40 / 0.6);
          border: 1px solid var(--color-border);
          border-radius: 0.5rem;
          color: var(--color-foreground);
          font-size: 0.875rem;
          outline: none;
          transition: border-color 0.2s;
        }
        .input:focus { border-color: var(--color-primary); }
      `}</style>
    </main>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4">
      <p className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</p>
      <p className="font-display mt-1 text-3xl">{value}</p>
    </div>
  );
}

function IconBtn({
  onClick,
  children,
  label,
  danger,
}: {
  onClick: () => void;
  children: React.ReactNode;
  label: string;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`rounded-full p-2 transition ${
        danger
          ? "text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
          : "text-muted-foreground hover:bg-primary/10 hover:text-primary"
      }`}
    >
      {children}
    </button>
  );
}

interface UploadInput {
  title: string;
  description?: string | null;
  category: Category;
  media_url: string;
  media_type: MediaType;
  thumbnail_url?: string | null;
  external_url?: string | null;
  featured?: boolean;
  views?: number;
}

function UploadForm({ onUploaded }: { onUploaded: (input: UploadInput) => Promise<void> }) {
  const importFn = useServerFn(importInstagramReel);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<Category>("video");
  const [externalUrl, setExternalUrl] = useState("");
  const [featured, setFeatured] = useState(false);
  const [views, setViews] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  // Instagram importer
  const [igUrl, setIgUrl] = useState("");
  const [importing, setImporting] = useState(false);
  const [importedMediaUrl, setImportedMediaUrl] = useState<string | null>(null);
  const [importedThumbUrl, setImportedThumbUrl] = useState<string | null>(null);

  const uploadToStorage = async (f: File, subdir: string) => {
    const ext = f.name.split(".").pop();
    const path = `${subdir}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("portfolio")
      .upload(path, f, { contentType: f.type, upsert: false });
    if (upErr) throw upErr;
    return supabase.storage.from("portfolio").getPublicUrl(path).data.publicUrl;
  };

  const handleImport = async () => {
    if (!igUrl.trim()) {
      toast.error("Paste an Instagram reel URL");
      return;
    }
    setImporting(true);
    try {
      const res = await importFn({ data: { url: igUrl.trim() } });
      setImportedMediaUrl(res.media_url);
      setImportedThumbUrl(res.thumbnail_url ?? null);
      if (!description && res.description) setDescription(res.description);
      setExternalUrl(igUrl.trim());
      setCategory("video");
      toast.success(`Imported reel (${res.size_mb} MB). Ready to publish.`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Import failed");
    } finally {
      setImporting(false);
    }
  };

  const clearImport = () => {
    setImportedMediaUrl(null);
    setImportedThumbUrl(null);
    setIgUrl("");
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file && !importedMediaUrl) {
      toast.error("Pick a file to upload or import from Instagram");
      return;
    }
    if (file && file.size > 524288000) {
      toast.error("File exceeds 500 MB limit");
      return;
    }
    if (coverFile && coverFile.size > 10 * 1024 * 1024) {
      toast.error("Cover image must be under 10 MB");
      return;
    }
    setUploading(true);
    setProgress(10);
    try {
      let media_url: string;
      let media_type: MediaType;
      let thumbnail_url: string | null = null;

      if (importedMediaUrl) {
        media_url = importedMediaUrl;
        media_type = "video";
        thumbnail_url = importedThumbUrl;
        setProgress(70);
      } else if (file) {
        setProgress(25);
        media_url = await uploadToStorage(file, category);
        setProgress(65);
        media_type = file.type.startsWith("video/") ? "video" : "image";
      } else {
        throw new Error("No media");
      }

      if (coverFile) {
        thumbnail_url = await uploadToStorage(coverFile, `${category}/covers`);
      }
      setProgress(85);

      await onUploaded({
        title,
        description: description || null,
        category,
        media_url,
        media_type,
        thumbnail_url,
        external_url: externalUrl || null,
        featured,
        views,
      });
      setProgress(100);

      setTitle("");
      setDescription("");
      setExternalUrl("");
      setFeatured(false);
      setViews(0);
      setFile(null);
      setCoverFile(null);
      clearImport();
      const input = document.getElementById("file-input") as HTMLInputElement | null;
      if (input) input.value = "";
      const cInput = document.getElementById("cover-input") as HTMLInputElement | null;
      if (cInput) cInput.value = "";
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
      setTimeout(() => setProgress(0), 800);
    }
  };


  return (
    <section className="glass mt-10 rounded-2xl p-8">
      <h2 className="font-display text-2xl">Add a new work</h2>
      <p className="mt-1 text-xs text-muted-foreground">
        Upload a file (up to 500 MB) or auto-import a reel from Instagram in original quality.
      </p>

      {/* Instagram importer */}
      <div className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-5">
        <div className="flex items-center gap-2">
          <Instagram size={16} className="text-primary" />
          <h3 className="text-sm font-medium uppercase tracking-widest text-primary">
            Auto-import from Instagram
          </h3>
        </div>
        <p className="mt-1 text-[11px] text-muted-foreground">
          Paste a public reel URL — we'll fetch the video in original quality, store it, and grab
          the cover automatically.
        </p>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row">
          <input
            type="url"
            value={igUrl}
            onChange={(e) => setIgUrl(e.target.value)}
            placeholder="https://www.instagram.com/reel/…"
            disabled={importing || !!importedMediaUrl}
            className="input flex-1"
          />
          {importedMediaUrl ? (
            <button
              type="button"
              onClick={clearImport}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-5 py-2.5 text-xs uppercase tracking-widest hover:border-primary"
            >
              <X size={14} /> Clear
            </button>
          ) : (
            <button
              type="button"
              onClick={handleImport}
              disabled={importing}
              className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground hover:opacity-90 disabled:opacity-50"
            >
              <Sparkles size={14} />
              {importing ? "Importing…" : "Import reel"}
            </button>
          )}
        </div>
        {importedMediaUrl && (
          <div className="mt-4 flex items-center gap-3 rounded-lg border border-primary/40 bg-background/40 p-3">
            {importedThumbUrl && (
              <img
                src={importedThumbUrl}
                alt="Imported cover"
                className="h-16 w-12 rounded object-cover"
              />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-xs text-primary">✓ Reel ready to publish</p>
              <p className="truncate text-[10px] text-muted-foreground">{importedMediaUrl}</p>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={submit} className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <Field label="Title (optional)">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Leave blank for Untitled"
            className="input"
          />
        </Field>
        <Field label="Category">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
            className="input"
          >
            <option value="video">Video Reel</option>
            <option value="web">Web Development</option>
          </select>
        </Field>
        <Field label="Views (e.g. 100000)">
          <input
            type="number"
            min={0}
            value={views}
            onChange={(e) => setViews(Math.max(0, parseInt(e.target.value || "0", 10)))}
            className="input"
          />
        </Field>
        <Field label="Description" full>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="input"
          />
        </Field>
        <Field label="External URL (optional)" full>
          <input
            type="url"
            placeholder="https://…"
            value={externalUrl}
            onChange={(e) => setExternalUrl(e.target.value)}
            className="input"
          />
        </Field>
        {!importedMediaUrl && (
          <Field label="Media file (image or video, max 500 MB)" full>
            <input
              id="file-input"
              type="file"
              accept="image/*,video/*"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="input file:mr-3 file:rounded file:border-0 file:bg-primary file:px-3 file:py-1 file:text-xs file:font-medium file:text-primary-foreground"
            />
            {file && (
              <p className="mt-2 text-[11px] text-muted-foreground">
                {file.name} — {(file.size / 1024 / 1024).toFixed(1)} MB
              </p>
            )}
          </Field>
        )}
        <Field label="Cover image (optional — used as video poster)" full>
          <input
            id="cover-input"
            type="file"
            accept="image/*"
            onChange={(e) => setCoverFile(e.target.files?.[0] ?? null)}
            className="input file:mr-3 file:rounded file:border-0 file:bg-primary file:px-3 file:py-1 file:text-xs file:font-medium file:text-primary-foreground"
          />
          {coverFile && (
            <p className="mt-2 text-[11px] text-muted-foreground">
              {coverFile.name} — {(coverFile.size / 1024 / 1024).toFixed(2)} MB
            </p>
          )}
        </Field>
        <label className="flex items-center gap-2 text-sm text-muted-foreground md:col-span-2">
          <input
            type="checkbox"
            checked={featured}
            onChange={(e) => setFeatured(e.target.checked)}
            className="h-4 w-4 accent-[color:var(--primary)]"
          />
          Mark as featured
        </label>

        {progress > 0 && (
          <div className="md:col-span-2">
            <div className="h-1 w-full overflow-hidden rounded-full bg-card">
              <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}
        <div className="md:col-span-2">
          <button
            type="submit"
            disabled={uploading}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-xs uppercase tracking-widest text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            <Upload size={14} />
            {uploading ? "Uploading…" : "Publish work"}
          </button>
        </div>
      </form>
    </section>
  );
}

function EditModal({
  work,
  onClose,
  onSave,
}: {
  work: Work;
  onClose: () => void;
  onSave: (patch: {
    title?: string;
    description?: string | null;
    category?: Category;
    external_url?: string | null;
    thumbnail_url?: string | null;
    featured?: boolean;
    views?: number;
  }) => Promise<void>;
}) {
  const [title, setTitle] = useState(work.title);
  const [description, setDescription] = useState(work.description ?? "");
  const [category, setCategory] = useState<Category>(work.category);
  const [externalUrl, setExternalUrl] = useState(work.external_url ?? "");
  const [thumbnailUrl, setThumbnailUrl] = useState(work.thumbnail_url ?? "");
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [featured, setFeatured] = useState(work.featured);
  const [views, setViews] = useState<number>(Number(work.views ?? 0));
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      let nextThumb: string | null = thumbnailUrl || null;
      if (coverFile) {
        if (coverFile.size > 10 * 1024 * 1024) {
          throw new Error("Cover image must be under 10 MB");
        }
        const ext = coverFile.name.split(".").pop();
        const path = `${category}/covers/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("portfolio")
          .upload(path, coverFile, { contentType: coverFile.type, upsert: false });
        if (upErr) throw upErr;
        nextThumb = supabase.storage.from("portfolio").getPublicUrl(path).data.publicUrl;
      }
      await onSave({
        title,
        description: description || null,
        category,
        external_url: externalUrl || null,
        thumbnail_url: nextThumb,
        featured,
        views,
      });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSaving(false);
    }
  };


  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur"
      onClick={onClose}
    >
      <div
        className="glass relative w-full max-w-2xl rounded-2xl p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-2 text-muted-foreground hover:bg-card hover:text-foreground"
          aria-label="Close"
        >
          <X size={16} />
        </button>
        <h2 className="font-display text-2xl">Edit work</h2>
        <form onSubmit={submit} className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          <Field label="Title (optional)">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Untitled"
              className="input"
            />
          </Field>
          <Field label="Category">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className="input"
            >
              <option value="video">Video Reel</option>
              <option value="web">Web Development</option>
            </select>
          </Field>
          <Field label="Views">
            <input
              type="number"
              min={0}
              value={views}
              onChange={(e) => setViews(Math.max(0, parseInt(e.target.value || "0", 10)))}
              className="input"
            />
          </Field>
          <Field label="Description" full>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="input"
            />
          </Field>
          <Field label="External URL" full>
            <input
              type="url"
              value={externalUrl}
              onChange={(e) => setExternalUrl(e.target.value)}
              className="input"
            />
          </Field>
          <Field label="Cover image URL (optional)" full>
            <input
              type="url"
              placeholder="https://…"
              value={thumbnailUrl}
              onChange={(e) => setThumbnailUrl(e.target.value)}
              className="input"
            />
          </Field>
          <Field label="Replace cover image (upload)" full>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setCoverFile(e.target.files?.[0] ?? null)}
              className="input file:mr-3 file:rounded file:border-0 file:bg-primary file:px-3 file:py-1 file:text-xs file:font-medium file:text-primary-foreground"
            />
            {thumbnailUrl && !coverFile && (
              <div className="mt-2">
                <img
                  src={thumbnailUrl}
                  alt="Current cover"
                  className="h-20 w-20 rounded-md border border-border object-cover"
                />
              </div>
            )}
          </Field>

          <label className="flex items-center gap-2 text-sm text-muted-foreground md:col-span-2">
            <input
              type="checkbox"
              checked={featured}
              onChange={(e) => setFeatured(e.target.checked)}
              className="h-4 w-4 accent-[color:var(--primary)]"
            />
            Featured
          </label>
          <div className="flex justify-end gap-2 md:col-span-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-full border border-border px-5 py-2.5 text-xs uppercase tracking-widest hover:border-primary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-full bg-primary px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground hover:opacity-90 disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <div className={full ? "md:col-span-2" : undefined}>
      <label className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        {label}
      </label>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function BulkUploadForm({
  onUploaded,
  onDone,
}: {
  onUploaded: (input: UploadInput) => Promise<void>;
  onDone: () => void;
}) {
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [done, setDone] = useState(0);
  const [failed, setFailed] = useState(0);

  const uploadOne = async (f: File) => {
    const ext = f.name.split(".").pop();
    const path = `video/bulk/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("portfolio")
      .upload(path, f, { contentType: f.type, upsert: false });
    if (upErr) throw upErr;
    return supabase.storage.from("portfolio").getPublicUrl(path).data.publicUrl;
  };

  const randomViews = () => Math.floor(20000 + Math.random() * 180001);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (files.length === 0) {
      toast.error("Pick one or more video files");
      return;
    }
    setUploading(true);
    setDone(0);
    setFailed(0);
    let ok = 0;
    let bad = 0;
    for (const f of files) {
      try {
        if (f.size > 524288000) throw new Error("File exceeds 500 MB");
        const media_url = await uploadOne(f);
        await onUploaded({
          title: "",
          description: null,
          category: "video",
          media_url,
          media_type: "video",
          thumbnail_url: null,
          external_url: null,
          featured: false,
          views: randomViews(),
        });
        ok += 1;
        setDone(ok);
      } catch (err) {
        bad += 1;
        setFailed(bad);
        console.error("Bulk upload failed for", f.name, err);
      }
    }
    onDone();
    toast.success(`Bulk done — ${ok} uploaded${bad ? `, ${bad} failed` : ""}.`);
    setFiles([]);
    const input = document.getElementById("bulk-file-input") as HTMLInputElement | null;
    if (input) input.value = "";
    setUploading(false);
  };

  const total = files.length;
  const progress = total ? Math.round(((done + failed) / total) * 100) : 0;

  return (
    <section className="glass mt-6 rounded-2xl p-8">
      <div className="flex items-center gap-2">
        <Upload size={16} className="text-primary" />
        <h2 className="font-display text-2xl">Bulk upload reels</h2>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Select multiple videos at once. Each gets no title and a random view count between 20K and
        200K.
      </p>
      <form onSubmit={submit} className="mt-5 space-y-4">
        <input
          id="bulk-file-input"
          type="file"
          accept="video/*"
          multiple
          onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
          disabled={uploading}
          className="input file:mr-3 file:rounded file:border-0 file:bg-primary file:px-3 file:py-1 file:text-xs file:font-medium file:text-primary-foreground"
        />
        {total > 0 && (
          <div className="space-y-2">
            <p className="text-[11px] text-muted-foreground">
              {total} file{total === 1 ? "" : "s"} selected
              {uploading && ` — ${done} done${failed ? `, ${failed} failed` : ""}`}
            </p>
            {uploading && (
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-border">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}
          </div>
        )}
        <button
          type="submit"
          disabled={uploading || total === 0}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground hover:opacity-90 disabled:opacity-50"
        >
          <Upload size={14} />
          {uploading ? `Uploading ${done + failed}/${total}…` : `Upload ${total || ""} videos`}
        </button>
      </form>
    </section>
  );
}
