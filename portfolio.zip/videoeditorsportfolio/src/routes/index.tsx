import { createFileRoute } from "@tanstack/react-router";
import { VideoIntro } from "@/components/VideoIntro";
import { WorksGallery } from "@/components/WorksGallery";
import { AboutSection } from "@/components/sections/AboutSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { ContactSection } from "@/components/sections/ContactSection";
import { useReveal } from "@/hooks/use-reveal";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Deepak — Web · Video · Marketing" },
      {
        name: "description",
        content:
          "Cinematic portfolio of Deepak — website development, video editing, digital marketing, Shopify, Wix Studio, and WhatsApp automation.",
      },
      { property: "og:title", content: "Deepak — Digital Creator" },
      {
        property: "og:description",
        content:
          "Premium websites, cinematic video, and growth-driven marketing for brands that refuse to feel ordinary.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@300;400;500;600&display=swap",
      },
    ],
  }),
  component: Index,
});

function Index() {
  useReveal();
  return (
    <main className="bg-background text-foreground">
      <VideoIntro
        firstName="Deepak"
        lastName=""
        tagline="Digital Creator · Portfolio 2026"
        subtitle={
          <>
            Crafting <span className="text-primary">premium websites</span>,
            cinematic visual stories, and growth-focused digital experiences
            that help brands stand out in a competitive digital world.
          </>
        }
      />
      <WorksGallery />
      <AboutSection />
      <ServicesSection />
      <ContactSection />
      <footer className="border-t border-border px-6 py-12 text-center text-xs uppercase tracking-[0.3em] text-muted-foreground">
        <p>© {new Date().getFullYear()} Deepak · Crafted with creativity and love</p>
      </footer>
    </main>
  );
}
