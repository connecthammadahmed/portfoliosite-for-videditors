import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import {
  listQuoteRequests,
  updateQuoteStatus,
  deleteQuoteRequest,
} from "@/lib/quotes.functions";
import { checkIsAdmin } from "@/lib/admin.functions";
import { toast } from "sonner";
import {
  Search,
  Trash2,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Users,
  Eye,
  MessageCircle,
  X,
} from "lucide-react";

export const Route = createFileRoute("/admin/video-leads")({
  head: () => ({
    meta: [{ title: "Video Leads — Admin" }, { name: "robots", content: "noindex,nofollow" }],
  }),
  component: VideoLeadsPage,
});

interface Lead {
  id: string;
  name: string;
  whatsapp: string;
  brand_name: string;
  content_type: string;
  requirements: string | null;
  service_type: "reel" | "podcast";
  videos_per_day: number;
  duration_days: number;
  estimated_price: number;
  status: "pending" | "contacted" | "closed";
  created_at: string;
}

function VideoLeadsPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [authReady, setAuthReady] = useState(false);

  const listFn = useServerFn(listQuoteRequests);
  const updateFn = useServerFn(updateQuoteStatus);
  const deleteFn = useServerFn(deleteQuoteRequest);
  const checkFn = useServerFn(checkIsAdmin);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | Lead["status"]>("all");
  const [serviceFilter, setServiceFilter] = useState<"all" | "reel" | "podcast">("all");
  const [viewing, setViewing] = useState<Lead | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(async ({ data }) => {
      if (!mounted) return;
      if (!data.user) {
        navigate({ to: "/auth" });
        return;
      }
      try {
        const r = (await checkFn()) as { isAdmin: boolean };
        if (!r.isAdmin) {
          toast.error("Admin access required");
          navigate({ to: "/" });
          return;
        }
        setAuthReady(true);
      } catch {
        navigate({ to: "/" });
      }
    });
    return () => {
      mounted = false;
    };
  }, [navigate, checkFn]);

  const { data: leads = [] } = useQuery({
    enabled: authReady,
    queryKey: ["video-leads"],
    queryFn: async (): Promise<Lead[]> => (await listFn()) as Lead[],
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return leads.filter((l) => {
      if (statusFilter !== "all" && l.status !== statusFilter) return false;
      if (serviceFilter !== "all" && l.service_type !== serviceFilter) return false;
      if (!q) return true;
      return (
        l.name.toLowerCase().includes(q) ||
        l.whatsapp.toLowerCase().includes(q) ||
        l.brand_name.toLowerCase().includes(q)
      );
    });
  }, [leads, search, statusFilter, serviceFilter]);

  const todayCount = useMemo(() => {
    const today = new Date().toDateString();
    return leads.filter((l) => new Date(l.created_at).toDateString() === today).length;
  }, [leads]);

  const pendingCount = leads.filter((l) => l.status === "pending").length;
  const contactedCount = leads.filter((l) => l.status === "contacted").length;

  const setStatus = async (id: string, status: Lead["status"]) => {
    try {
      await updateFn({ data: { id, status } });
      qc.invalidateQueries({ queryKey: ["video-leads"] });
      toast.success("Status updated");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this lead?")) return;
    try {
      await deleteFn({ data: { id } });
      qc.invalidateQueries({ queryKey: ["video-leads"] });
      toast.success("Lead deleted");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  };

  const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");
  const formatDate = (s: string) =>
    new Date(s).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  const waLink = (l: Lead) => {
    const num = l.whatsapp.replace(/\D/g, "");
    const text = encodeURIComponent(
      `Hi ${l.name}, thanks for your quote request for ${SERVICE_LABEL[l.service_type]} (${formatINR(l.estimated_price)}).`,
    );
    return `https://wa.me/${num}?text=${text}`;
  };

  if (!authReady) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-background px-4 py-8 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <Link
              to="/admin"
              className="mb-2 inline-flex items-center gap-1.5 text-xs text-muted-foreground transition hover:text-primary"
            >
              <ArrowLeft size={12} /> Back to Admin
            </Link>
            <h1 className="font-display text-4xl">Video Quote Leads</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              All quote requests from the pricing calculator.
            </p>
          </div>
        </div>

        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard icon={Users} label="Total Leads" value={leads.length} color="primary" />
          <StatCard icon={Clock} label="Today" value={todayCount} color="accent" />
          <StatCard icon={Clock} label="Pending" value={pendingCount} color="primary" />
          <StatCard
            icon={CheckCircle2}
            label="Contacted"
            value={contactedCount}
            color="accent"
          />
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search
              size={14}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, WhatsApp or brand…"
              className="h-10 w-full rounded-xl border border-white/10 bg-card/50 pl-9 pr-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
            className="h-10 rounded-xl border border-white/10 bg-card/50 px-3 text-sm outline-none focus:border-primary"
          >
            <option value="all">All statuses</option>
            <option value="pending">Pending</option>
            <option value="contacted">Contacted</option>
            <option value="closed">Closed</option>
          </select>
          <select
            value={serviceFilter}
            onChange={(e) => setServiceFilter(e.target.value as typeof serviceFilter)}
            className="h-10 rounded-xl border border-white/10 bg-card/50 px-3 text-sm outline-none focus:border-primary"
          >
            <option value="all">All services</option>
            <option value="reel">Reel Editing</option>
            <option value="podcast">Podcast / B-Roll</option>
          </select>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-white/10 bg-card/40">
          <table className="w-full text-sm">
            <thead className="border-b border-white/10 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">WhatsApp</th>
                <th className="px-4 py-3">Brand</th>
                <th className="px-4 py-3">Service</th>
                <th className="px-4 py-3 text-right">Estimated</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground">
                    No leads found.
                  </td>
                </tr>
              ) : (
                filtered.map((l) => (
                  <tr key={l.id} className="border-b border-white/5 hover:bg-white/[0.02]">
                    <td className="px-4 py-3 font-medium">{l.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{l.whatsapp}</td>
                    <td className="px-4 py-3">{l.brand_name}</td>
                    <td className="px-4 py-3">
                      <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-xs">
                        {SERVICE_LABEL[l.service_type]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-medium text-primary tabular-nums">
                      {formatINR(l.estimated_price)}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {formatDate(l.created_at)}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={l.status} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button
                          onClick={() => setViewing(l)}
                          title="View"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-muted-foreground transition hover:border-primary hover:text-primary"
                        >
                          <Eye size={13} />
                        </button>
                        <a
                          href={waLink(l)}
                          target="_blank"
                          rel="noopener noreferrer"
                          title="WhatsApp"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-muted-foreground transition hover:border-green-500 hover:text-green-500"
                        >
                          <MessageCircle size={13} />
                        </a>
                        {l.status !== "contacted" && (
                          <button
                            onClick={() => setStatus(l.id, "contacted")}
                            title="Mark contacted"
                            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-muted-foreground transition hover:border-primary hover:text-primary"
                          >
                            <CheckCircle2 size={13} />
                          </button>
                        )}
                        <button
                          onClick={() => remove(l.id)}
                          title="Delete"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-muted-foreground transition hover:border-destructive hover:text-destructive"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {viewing && <LeadModal lead={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}

const SERVICE_LABEL: Record<"reel" | "podcast", string> = {
  reel: "Reel Editing",
  podcast: "Podcast / B-Roll",
};

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Users;
  label: string;
  value: number;
  color: "primary" | "accent";
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-card/40 p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <Icon size={16} className={color === "primary" ? "text-primary" : "text-accent"} />
      </div>
      <p className="mt-2 font-display text-4xl tabular-nums">{value}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: "pending" | "contacted" | "closed" }) {
  const styles = {
    pending: "border-primary/40 bg-primary/10 text-primary",
    contacted: "border-green-500/40 bg-green-500/10 text-green-500",
    closed: "border-white/15 bg-white/5 text-muted-foreground",
  } as const;
  return (
    <span
      className={`inline-block rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-wider ${styles[status]}`}
    >
      {status}
    </span>
  );
}

function LeadModal({ lead, onClose }: { lead: Lead; onClose: () => void }) {
  const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
      <div
        className="relative z-10 w-full max-w-lg rounded-3xl border border-white/10 bg-card p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full border border-white/10 text-muted-foreground hover:text-primary"
        >
          <X size={14} />
        </button>
        <h3 className="font-display text-3xl">{lead.name}</h3>
        <p className="text-sm text-muted-foreground">{lead.brand_name}</p>
        <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
          <Detail label="WhatsApp" value={lead.whatsapp} />
          <Detail label="Content Type" value={lead.content_type} />
          <Detail label="Service" value={SERVICE_LABEL[lead.service_type]} />
          <Detail label="Estimated" value={formatINR(lead.estimated_price)} highlight />
          <Detail label="Videos / day" value={String(lead.videos_per_day)} />
          <Detail label="Duration" value={`${lead.duration_days} days`} />
        </div>
        {lead.requirements && (
          <div className="mt-5">
            <p className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">
              Requirements
            </p>
            <p className="rounded-xl border border-white/10 bg-black/30 p-3 text-sm whitespace-pre-wrap">
              {lead.requirements}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Detail({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p
        className={`mt-0.5 ${highlight ? "font-display text-xl text-primary tabular-nums" : "text-sm"}`}
      >
        {value}
      </p>
    </div>
  );
}
