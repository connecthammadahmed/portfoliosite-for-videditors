import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Admin Sign In" },
      { name: "description", content: "Admin sign-in to manage portfolio work." },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/admin", replace: true });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Password reset link sent. Check your email.");
        setMode("signin");
        return;
      }
      if (mode === "signup") {

        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        toast.success("Account created. Signing you in…");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          // Auto-fallback: if no account exists, create it on the fly
          if (/invalid login credentials/i.test(error.message)) {
            const { error: signUpErr } = await supabase.auth.signUp({
              email,
              password,
              options: { emailRedirectTo: `${window.location.origin}/admin` },
            });
            if (signUpErr) throw signUpErr;
            const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
            if (signInErr) throw signInErr;
            toast.success("Admin account created. Signed in.");
          } else {
            throw error;
          }
        }
      }
      navigate({ to: "/admin", replace: true });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main
      className="flex min-h-screen items-center justify-center px-6 py-16"
      style={{ backgroundImage: "var(--gradient-cinematic)" }}
    >
      <div className="glass w-full max-w-md rounded-3xl p-10">
        <Link
          to="/"
          className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground hover:text-primary"
        >
          ← Back to site
        </Link>
        <h1 className="font-display mt-4 text-4xl leading-tight">
          {mode === "signin"
            ? "Admin Sign In"
            : mode === "signup"
              ? "Create Admin Account"
              : "Forgot Password"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {mode === "forgot"
            ? "Enter your email and we'll send a reset link."
            : "Manage portfolio work, upload media, and curate your gallery."}
        </p>

        <form onSubmit={submit} className="mt-8 space-y-4">
          <div>
            <label className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="mt-2 w-full rounded-lg border border-border bg-input/40 px-4 py-3 text-sm text-foreground outline-none transition focus:border-primary"
            />
          </div>
          {mode !== "forgot" && (
            <div>
              <label className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="mt-2 w-full rounded-lg border border-border bg-input/40 px-4 py-3 text-sm text-foreground outline-none transition focus:border-primary"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-primary px-6 py-3 text-sm font-medium uppercase tracking-widest text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
          >
            {loading
              ? "…"
              : mode === "signin"
                ? "Sign In"
                : mode === "signup"
                  ? "Create Account"
                  : "Send Reset Link"}
          </button>
        </form>





      </div>
    </main>
  );
}
