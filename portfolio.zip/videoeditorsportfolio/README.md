# Deepak Portfolio — Full Setup Guide

> A cinematic portfolio website with admin dashboard, video editing quote system, and Discord notifications. Built with **TanStack Start**, **React 19**, **TypeScript**, **Tailwind CSS v4**, and **Supabase**.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Tech Stack](#tech-stack)
3. [Prerequisites](#prerequisites)
4. [Local Development Setup](#local-development-setup)
5. [Environment Variables](#environment-variables)
6. [Database Setup](#database-setup)
7. [Admin Account Setup](#admin-account-setup)
8. [Running Locally](#running-locally)
9. [VPS Deployment Guide](#vps-deployment-guide)
10. [Production Checklist](#production-checklist)
11. [Troubleshooting](#troubleshooting)

---

## Project Overview

This is a full-stack portfolio application featuring:

- **Public Portfolio**: Cinematic landing page with video intro, works gallery, about section, services, and contact form
- **Admin Dashboard**: Protected area to manage portfolio works, upload media, import Instagram reels, and view video editing quote requests
- **Video Quote System**: Public pricing calculator with form submission that sends Discord webhook notifications
- **Authentication**: Email/password auth with role-based admin access
- **Storage**: Supabase Storage for portfolio images and videos

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | TanStack Start (React 19 + Vite 7) |
| Language | TypeScript 5.8 |
| Styling | Tailwind CSS v4 |
| UI Components | Radix UI + shadcn/ui |
| Backend | Supabase (PostgreSQL + Auth + Storage) |
| Animation | GSAP |
| Icons | Lucide React |
| Validation | Zod |
| Package Manager | Bun |

---

## Prerequisites

Before starting, install these tools on your machine:

1. **Node.js 20+** — [Download](https://nodejs.org/)
2. **Bun** — Install with: `curl -fsSL https://bun.sh/install | bash`
3. **Git** — [Download](https://git-scm.com/downloads)
4. **A Supabase project** — [Create free account](https://supabase.com/)

For VPS deployment, you also need:

5. **A VPS** — Ubuntu 22.04+ server with at least 1GB RAM
6. **A domain name** — Pointed to your VPS IP

---

## Local Development Setup

### Step 1: Clone the Project

```bash
git clone <your-repo-url>
cd <project-folder>
```

### Step 2: Install Dependencies

```bash
bun install
```

If you don't have Bun, you can use npm:

```bash
npm install
```

### Step 3: Create Environment File

Create a `.env` file in the project root with the following variables:

```env
# Supabase Configuration (Public - used in browser)
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
VITE_SUPABASE_PROJECT_ID=your-project-id

# Server-only Supabase Configuration (kept secret)
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_PUBLISHABLE_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_DB_URL=postgresql://postgres:[password]@db.your-project-ref.supabase.co:5432/postgres

# Discord Webhook (optional - for quote notifications)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...
```

> **Where to get these values:**
> - Go to your Supabase dashboard → Project Settings → API
> - `URL` = VITE_SUPABASE_URL / SUPABASE_URL
> - `anon public` key = VITE_SUPABASE_PUBLISHABLE_KEY / SUPABASE_PUBLISHABLE_KEY
> - `service_role secret` key = SUPABASE_SERVICE_ROLE_KEY (**NEVER share this**)
> - Project Settings → Database → Connection string = SUPABASE_DB_URL

### Step 4: Set Up Supabase Database

Run the migrations in your Supabase SQL Editor:

1. Go to Supabase dashboard → SQL Editor
2. Open each file in `supabase/migrations/` folder (in chronological order by filename)
3. Run each migration in the SQL Editor

Migration files should create:
- `profiles` table (auto-created via trigger on auth.users)
- `user_roles` table with admin role support
- `works` table for portfolio items
- `video_quote_requests` table for quote submissions
- Storage bucket `portfolio` (public)
- RLS policies for security

### Step 5: Configure Supabase Auth

1. In Supabase dashboard, go to Authentication → Settings
2. Enable **Email** provider
3. Set **Site URL** to `http://localhost:3000`
4. Set **Redirect URLs** to include:
   - `http://localhost:3000`
   - `http://localhost:3000/admin`
   - `http://localhost:3000/reset-password`

### Step 6: Create Storage Bucket

1. Go to Supabase dashboard → Storage
2. Create a new bucket named `portfolio`
3. Set it as **Public**
4. Upload policy: Allow public read access

---

## Environment Variables

### Required Variables

| Variable | Source | Description |
|----------|--------|-------------|
| `VITE_SUPABASE_URL` | Supabase Project Settings → API | Supabase project URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Supabase Project Settings → API | Public anon key for browser |
| `VITE_SUPABASE_PROJECT_ID` | Supabase Project Settings → General | Project reference ID |
| `SUPABASE_URL` | Same as above | Server-side Supabase URL |
| `SUPABASE_PUBLISHABLE_KEY` | Same as above | Server-side anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase Project Settings → API | Secret key (bypasses RLS) |
| `SUPABASE_DB_URL` | Supabase Project Settings → Database | Direct PostgreSQL connection |

### Optional Variables

| Variable | Description |
|----------|-------------|
| `DISCORD_WEBHOOK_URL` | Discord webhook for quote form notifications |

---

## Database Setup

### Manual Schema Setup (if migrations don't exist)

If you don't have the migration files, create these tables manually in Supabase SQL Editor:

#### 1. App Role Enum

```sql
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
```

#### 2. User Roles Table

```sql
CREATE TABLE public.user_roles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    UNIQUE (user_id, role)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
```

#### 3. Works Table (Portfolio Items)

```sql
CREATE TABLE public.works (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title text NOT NULL DEFAULT 'Untitled',
    description text,
    category text NOT NULL CHECK (category IN ('web', 'video', 'marketing')),
    media_url text NOT NULL,
    media_type text NOT NULL CHECK (media_type IN ('image', 'video')),
    thumbnail_url text,
    external_url text,
    featured boolean DEFAULT false,
    views integer DEFAULT 0,
    sort_order integer DEFAULT 0,
    created_by uuid REFERENCES auth.users(id),
    created_at timestamptz DEFAULT now()
);

GRANT SELECT ON public.works TO anon, authenticated;
GRANT ALL ON public.works TO service_role;

ALTER TABLE public.works ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view works" ON public.works
    FOR SELECT TO anon, authenticated USING (true);
```

#### 4. Video Quote Requests Table

```sql
CREATE TABLE public.video_quote_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    whatsapp text NOT NULL,
    brand_name text NOT NULL,
    content_type text NOT NULL,
    requirements text,
    service_type text NOT NULL CHECK (service_type IN ('reel', 'podcast')),
    videos_per_day integer NOT NULL,
    duration_days integer NOT NULL,
    estimated_price integer NOT NULL,
    status text DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'closed')),
    created_at timestamptz DEFAULT now()
);

GRANT ALL ON public.video_quote_requests TO service_role;

ALTER TABLE public.video_quote_requests ENABLE ROW LEVEL SECURITY;
```

#### 5. Profiles Table (Auto-created via Trigger)

```sql
CREATE TABLE public.profiles (
    id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email text,
    display_name text,
    created_at timestamptz DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT TO authenticated USING (auth.uid() = id);
```

#### 6. Auth Trigger (Auto-create profile on signup)

```sql
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)));
  RETURN NEW;
END;
$$;
```

#### 7. Role Check Function

```sql
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;
```

#### 8. Create Storage Bucket

Go to Supabase Dashboard → Storage → New Bucket:
- Name: `portfolio`
- Public: Yes

---

## Admin Account Setup

### Step 1: Create First Admin Account

1. Start the dev server (see below)
2. Go to `http://localhost:3000/auth`
3. Enter your email and password, then click **Sign In**
4. If account doesn't exist, it will auto-create one

### Step 2: Grant Admin Role

After signing up, manually assign the admin role in Supabase:

1. Go to Supabase dashboard → Table Editor → `user_roles`
2. Insert a new row:
   - `user_id`: Your user's UUID (find it in Authentication → Users)
   - `role`: `admin`

Or run this SQL (replace with your actual user ID):

```sql
INSERT INTO public.user_roles (user_id, role)
VALUES ('your-user-uuid-here', 'admin');
```

### Step 3: Verify Admin Access

1. Go to `http://localhost:3000/admin`
2. You should see the Admin Dashboard with stats, upload forms, and work management

---

## Running Locally

### Development Mode (with hot reload)

```bash
bun run dev
```

The app will start at: **http://localhost:3000**

### Build for Production (locally)

```bash
bun run build
```

### Preview Production Build Locally

```bash
bun run preview
```

---

## VPS Deployment Guide

This guide covers deploying the app on an Ubuntu 22.04+ VPS using **PM2** and **Nginx**.

### Step 1: Prepare Your VPS

SSH into your server:

```bash
ssh root@your-server-ip
```

Update system packages:

```bash
apt update && apt upgrade -y
```

Install essential tools:

```bash
apt install -y git curl nginx build-essential
```

### Step 2: Install Node.js and Bun

Install Node.js 20+:

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
```

Install Bun:

```bash
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc
```

Verify installations:

```bash
node --version   # Should show v20.x
bun --version      # Should show 1.x
```

### Step 3: Clone Project and Install Dependencies

```bash
cd /var/www
git clone <your-repo-url>
cd <project-folder>
bun install
```

### Step 4: Create Production Environment File

```bash
nano .env
```

Add the same environment variables as local development, but update URLs to your production domain:

```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
VITE_SUPABASE_PROJECT_ID=your-project-id

SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_PUBLISHABLE_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_DB_URL=postgresql://postgres:[password]@db.your-project-ref.supabase.co:5432/postgres

# Discord Webhook (optional)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...

# Production flag (optional)
NODE_ENV=production
```

Save and exit: `Ctrl+O`, `Enter`, `Ctrl+X`

### Step 5: Build the Application

```bash
bun run build
```

### Step 6: Install PM2 and Start the App

Install PM2 globally:

```bash
npm install -g pm2
```

Create a PM2 ecosystem file:

```bash
nano ecosystem.config.js
```

Add this configuration:

```javascript
module.exports = {
  apps: [
    {
      name: 'deepak-portfolio',
      script: 'node_modules/.bin/vite',
      args: 'preview --host 0.0.0.0 --port 3000',
      cwd: '/var/www/<project-folder>',
      env: {
        NODE_ENV: 'production',
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
    },
  ],
};
```

Start the app with PM2:

```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
```

> Run the command PM2 outputs to enable startup on boot.

### Step 7: Configure Nginx as Reverse Proxy

Create an Nginx config:

```bash
nano /etc/nginx/sites-available/deepak-portfolio
```

Add this configuration (replace `your-domain.com`):

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
}
```

Enable the site:

```bash
ln -s /etc/nginx/sites-available/deepak-portfolio /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### Step 8: Set Up SSL with Let's Encrypt

Install Certbot:

```bash
apt install -y certbot python3-certbot-nginx
```

Obtain SSL certificate:

```bash
certbot --nginx -d your-domain.com -d www.your-domain.com
```

Follow the prompts. Certbot will automatically update your Nginx config with SSL settings.

### Step 9: Update Supabase Auth Redirect URLs

Go to Supabase Dashboard → Authentication → URL Configuration:

Add these redirect URLs:
- `https://your-domain.com`
- `https://your-domain.com/admin`
- `https://your-domain.com/reset-password`

Update **Site URL** to: `https://your-domain.com`

### Step 10: Verify Deployment

Visit `https://your-domain.com` — your portfolio should be live!

Test admin access:
1. Go to `https://your-domain.com/auth`
2. Sign in with your admin credentials
3. Go to `https://your-domain.com/admin`

---

## Production Checklist

Before launching to production, verify:

- [ ] All environment variables are set correctly
- [ ] Supabase Auth redirect URLs include production domain
- [ ] Supabase Site URL is set to production domain
- [ ] Database migrations have been applied
- [ ] `portfolio` storage bucket exists and is public
- [ ] Admin role is assigned in `user_roles` table
- [ ] Discord webhook URL is configured (optional)
- [ ] SSL certificate is active
- [ ] Nginx is configured with proper proxy headers
- [ ] PM2 is set to auto-start on boot
- [ ] Build completes without errors

---

## Troubleshooting

### Build fails with "Failed to resolve import"

Make sure all dependencies are installed:
```bash
bun install
```

### Port 3000 already in use

Kill the process using port 3000:
```bash
lsof -ti:3000 | xargs kill -9
```

Or change the port:
```bash
bun run dev -- --port 4000
```

### Admin page shows "Admin access required"

You need to manually insert an admin role in the database:
```sql
INSERT INTO public.user_roles (user_id, role)
VALUES ('your-uuid-from-auth-users', 'admin');
```

### Discord webhook not working

- Verify `DISCORD_WEBHOOK_URL` is set correctly in `.env`
- Check server logs for errors: `pm2 logs deepak-portfolio`

### Images/videos not loading

- Check that the `portfolio` bucket exists in Supabase Storage
- Verify the bucket is set to **Public**
- Check browser console for CORS errors

### Database connection errors

- Verify `SUPABASE_DB_URL` is correct
- Check that your IP is allowed in Supabase Database → Connection Pooling → IPv4 add-ons

### 502 Bad Gateway from Nginx

- Check if the app is running: `pm2 status`
- Check app logs: `pm2 logs deepak-portfolio`
- Verify Nginx config: `nginx -t`

---

## Useful Commands

### Local Development

```bash
bun run dev       # Start dev server
bun run build     # Build for production
bun run preview   # Preview production build
bun run lint      # Run ESLint
bun run format    # Format with Prettier
```

### VPS / Production

```bash
# PM2 commands
pm2 status                    # Check app status
pm2 logs deepak-portfolio     # View logs
pm2 restart deepak-portfolio  # Restart app
pm2 stop deepak-portfolio     # Stop app
pm2 delete deepak-portfolio   # Remove from PM2

# Nginx commands
nginx -t                      # Test config
systemctl restart nginx       # Restart nginx
systemctl status nginx        # Check nginx status

# After code updates on VPS
cd /var/www/<project-folder>
git pull
bun install
bun run build
pm2 restart deepak-portfolio
```

---

## Support

For issues related to:
- **Supabase**: Check [Supabase Documentation](https://supabase.com/docs)
- **TanStack Start**: Check [TanStack Documentation](https://tanstack.com/start/latest)
- **Deployment**: Review this README or check server logs with `pm2 logs`

---

**License:** Private — For client use only.
